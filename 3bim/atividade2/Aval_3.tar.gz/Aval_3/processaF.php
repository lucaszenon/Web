<?php
	include_once 'fornecedores.class.php';
	include_once 'conexaoF.class.php';
//recebe os dados do formúlario
	$dadosOK = true;
		
		$fornecedor = new Fornecedor($_POST['txtNome'],$_POST['txtData'],$_POST['txtEmail']);
		
		$MySQL = new MySQL;
		
		try{
			$MySQL->inserirFornecedor($->getNome(),$->getDataFundacao(),$->getEmail());
			echo "<b>Dados gravados com sucesso</b> <br>";
		}catch (Exception $e){
			echo "Erro ao inserir: ". $e->getMessage() . "<br>";
		 }
	}
?>
