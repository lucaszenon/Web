<script type="text/javascript" src="js/script.js"></script>		
<?php
	require_once 'init.php';
	// abre a conexão
	$PDO=db_connect();
	/* SQL para contar o total de registros */
	$sql_count = "SELECT COUNT(*) AS total FROM clientes ORDER BY nomeCliente ASC";
	// SQL para selecionar os registros
	$sql = " SELECT idCliente, nomeCliente, dataCadastro, email FROM clientes ORDER BY nomeCliente ASC";
	// conta o total de registros
	$stmt_count=$PDO->prepare($sql_count);
	$stmt_count->execute();
	$total=$stmt_count->fetchColumn();
	// seleciona os registros
	$stmt=$PDO->prepare($sql);
	$stmt->execute();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
	<link type="text/css" href="js/jquery-ui.css" rel="stylesheet"/>
    <link type="text/css" href="style.css" rel="stylesheet"/>
    <script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.js"></script>
    <script type="text/javascript" src="js/script.js"></script>
	<script type ="text/javascript" src="js/datepicker-pt-BR.js"></script>
			
	<script>
function a(){
$("#data").datepicker({
showOn:  "button",
minDate: new Date(2000, 1 - 1, 1), 
maxDate: 0,        
buttonImage: "horse.jpg",
buttonImageOnly: true
});
 }
function b(){
$("#data").datepicker({
showOn:  "button",
minDate: new Date(1950, 1 - 1, 1), 
maxDate: 0,        
buttonImage: "horse.jpg",
buttonImageOnly: true
});
 }
 </script>
<div class="cabecalho">
			<div id="logo"><img src="images.jpg"></img></div>
			<div id="menu">
			<a href="index.php">HOME</a>
			<a href="clientes.php">CLIENTES</a>
			<a href="fornecedores.php">FORNECEDORES</a>
			<a href="sobre.php">SOBRE</a></div></div>

		<h1>Cadastro de Fornecedor</h1>
	<div class="container">
		<p> <input type="button" href="form-add.php" name="novo" value="Novo"  onClick="chama(this)"></p>
		<h2>Lista de fornecedores</h2>
		<p>Total de fornecedores: 	<?php echo $total ?></p>
		<?php if($total > 0): ?>
		<table width="100%" border="1">
			<thead>
				<tr>
					<th>Número do Cliente</th>
					<th>Nome</th>
					<th>Email</th>
					<th>Data de Cadastro</th>
				</tr>
			</thead>
			<tbody>
				<?php while($cliente = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
			<tr>
				<td><?php echo $cliente['idCliente']?>;</td>
				<td><?php echo $cliente['nomeCliente']?>;</td>
				<td><?php echo $cliente['email']?>;</td>
				<td><?php echo dateConvert($cliente['dataCadastro'])?></td>
				<td><a href="form-edit.php?id=<?php echo $cliente['idCliente']?>">Editar</a>
				<a href="delete.php?id=<?php echo $cliente['idCliente']?>"onclick="return confirm('Tem certeza que deseja excluir?');">Excluir</a></td>
				</tr>
				<?php endwhile; ?>
			</tbody>
		</table>
		<?php else: ?>
		<p>Nenhum cliente registrado</p>
		<?php endif; ?>
</div>
