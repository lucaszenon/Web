<div class="container">
<?php
  // inclui classes necessárias
  spl_autoload_register(function ($class_name)
  {
    include 'html/'.$class_name.'.class.php';
  });
	require_once 'init.php';
	// abre a conexão
	$PDO=db_connect();
	/* SQL para contar o total de registros */
	$sql_count = "SELECT COUNT(*) AS total FROM clientes ORDER BY nomeCliente ASC";
	// SQL para selecionar os registros
	$sql = "SELECT idCliente, nomeCliente, dataCadastro, email FROM clientes ORDER BY nomeCliente ASC";
	// conta o total de registros
	$stmt_count=$PDO->prepare($sql_count);
	$stmt_count->execute();
	$total=$stmt_count->fetchColumn();
	// seleciona os registros
	$stmt=$PDO->prepare($sql);
	$stmt->execute();

  // corrigir caracteres
  $html = new TElement('html');
  $html->lang = 'pt-br';
  //instancia seção head
  $head = new TElement('head');
  $html->add($head); //adiciona ao html
  $meta = new TElement('meta');
  $meta->charset = 'utf-8';
  $head->add($meta);

  $body = new TElement('body');
  $body->bgcolor = '#ffffdd';
  $html->add($body);


  //instancia objeto-tabela
  $tabela = new TTable;
  //define algumas propriedades
  $tabela->width = 600;
  $tabela->border = 1;
  //instancia uma linha para o cabeçalho
  $cabecalho = $tabela->addRow();
  //define a cor de fundo
  $cabecalho->bgcolor = '#a31223';
  //adiciona células
  $id = $cabecalho->addCell('<b>Id</b>');
  $nome = $cabecalho->addCell('<b>Nome</b>');
  $email = $cabecalho->addCell('<b>E-Mail</b>');
  $data = $cabecalho->addCell('<b>Data Cadastro</b>');
  
  $i = 0;
  $total = 0;

    // verifica qual cor utilizará para o fundo
    $bgcolor = '#000';
    // adiciona uma linha para os dados
    $linha = $tabela->addRow();
    $linha->bgcolor = $bgcolor;
  $i = 0;
 
  while($cliente = $stmt->fetch(PDO::FETCH_ASSOC))
  {
    // verifica qual cor utilizará para o fundo
    $bgcolor = ($i % 2) == 0 ? '#d0d0d0' : '#ffffff';
    $linha = $tabela->addRow();
    $linha->bgcolor = $bgcolor;
    // adiciona as células
    $id = $linha->addCell($cliente['idCliente']);
    $linha->addCell($cliente['nomeCliente']);
    $linha->addCell($cliente['email']);
    $data = $linha->addCell(dateConvert($cliente['dataCadastro']));
    
    $i++;
  }
?>	<div class="tab">
	<?php
  $body->add($tabela);
	$style = new TStyle('centraliza');
	
	$style->margin_left='400px';
	$style->show();
	$tabela->class = 'centraliza';

	
  $html->show();
  ?>
 </div><?php
 
?>
</div>
