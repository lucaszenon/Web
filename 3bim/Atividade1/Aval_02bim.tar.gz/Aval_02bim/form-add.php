<?php
	require 'init.php';
?>
<!DOCTYPE html>

	<body>
<div class="container">	
<head>
		<title>Envio de dados</title>
		<meta charset="utf-8">
		<link type ="text/css" href="js/jquery-ui.css" rel="stylesheet"/>
		<script type ="text/javascript" src ="js/jquery-2.1.1.min.js"></script>
		<script type ="text/javascript" src="js/jquery-ui.js"></script>
		<script type ="text/javascript" src="js/datepicker-pt-BR.js"></script>
</head>
	<form method="post" name="formCadastro" action="add.php" enctype="multipart/form-data">
			<h1>Cadastro Clientes</h1>
			<table width="100%">
				<tr>
					<th width="18%"> Nome </th>
					<td width="82%"><input type="text" name="txtNome"></td>
				</tr>	
				<tr>
					<th> Email </th>
					<td><input type="email" name="txtEmail"></td>
				</tr>
				<tr>
					<th> Data Cadastro</th>
					<td><input id="data" onlyread="true" type="text" name="txtData" readonly onclick="a()">	</td>

				</tr>

				<tr>
					<td></td>
					<td><input type="submit" name="btnEnviar" value="Cadastrar">
						<input type="reset" name="btnLimpar" value="Limpar"></td>
				</tr>
			</table>
		</form>
</div>
	</body>
</html>
