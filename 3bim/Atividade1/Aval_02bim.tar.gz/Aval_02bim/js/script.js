$(document).ready(function(e){
  $("#menu a").click(function(e){
      e.preventDefault();
      var href = $(this).attr('href');
      $(".container").load(href + " .container");
  });
});
function chama(botao) {
	var href = $(botao).attr('href');
	$(".container").load(href + " .container");
	
}
;
