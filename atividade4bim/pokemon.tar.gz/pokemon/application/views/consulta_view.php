<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Pokémon GO</title>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


	<link rel="stylesheet" href="http://localhost/pokemon/assets/main.css">
</head>
<body id="imagi">
	<div id="header">
			<?php
				if(null != $this->session->userdata('logado')) {
				}
				else{
					redirect(base_url("login"));
				}
			?>
	</div>	<div id="imagi">  </div>
	<nav class="navbar navbar-default">

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Cadastrar Pokémon<span class="sr-only">(current)</span></a></li>
        <li><a href="#">Consultar Pokémon</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
	<table class="table table-striped">
    		<thead>
      		<tr>
        			<th>Nome do Pokémon</th>
        			<th>Tipo de Pokémon</th>
        			<th>Data de Captura</th>
					<th></th>
					<th></th>
     			</tr>
    		</thead>
    		<tbody>
				<tr class="default">
					<?php
              			foreach($pokemon as $pok){
               				echo "<tr>";
                 				echo "<td>".$pok->Nome."</td>";
                 				echo "<td>".$pok->Tipo_Pokemon."</td>";
                  			echo "<td>".$pok->Data_Captura."</td>";
                  			echo "<td>".anchor('../consulta/deletar/'.$pok->id_pokemon, '<button type="button" class="btn btn-success">Excluir</button>', 'id="$pok->id_pokemon"')."</td>";
                  			echo "<td>".anchor('../consulta/editar/'.$pok->id_pokemon, '<button type="button" class="btn btn-success">Editar</button>', 'id="$pok->id_pokemon"')."</td>";
              			}
               		?>
           		</tr>
         	</tbody>
      </table>



</body>
</html>
