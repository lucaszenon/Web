<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Pokémon GO</title>
	
	<link rel="stylesheet" href="http://localhost/pokemon/assets/estilo.css">
</head>
<body>
	
	<div class="container">

      <div class="login">
      	<img src="http://localhost/pokemon/assets/images/logo.png" class="main" id="#img">

    
      	<div class ="form-login">

		<?php echo validation_errors();
			echo form_open(base_url('login/logar'),array('id'=>'login')) .
			form_input(array('id'=>'login', 'name'=>'login','Placeholder'=>'Login','value'=>set_value('login'))) .
			form_password(array('id'=>'senha','name'=>'senha','Placeholder'=>'Senha')) .
			form_submit("btnLogin","Entrar") .
			form_close(); ?>
    	</div> 
      </div>
    </div>
</body>
</html>
