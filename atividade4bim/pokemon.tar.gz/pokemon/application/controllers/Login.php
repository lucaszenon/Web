<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		$this->load->helper('form');		
		$this->load->view('login_view');
	}
	
	public function logar(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('login','Login','required');
		$this->form_validation->set_rules('senha','Senha','required');
		if($this->form_validation->run() == FALSE){
			echo "Campos vazios";
		}
		else{
			$this->db->where('login',$this->input->post('login'));	
			$this->db->where('senha',$this->input->post('senha'));
			$usuario = $this->db->get('usuario')->result();
			if(count($usuario)==1){
				$dadosSessao['usuario'] = $usuario[0];
				$dadosSessao['logado'] = TRUE;
				$this->session->set_userdata($dadosSessao);
				redirect(base_url("home"));			
			}
			else{
				$dadosSessao['usuario'] = NULL;
				$dadosSessao['logado'] = FALSE;
				$this->session->set_userdata($dadosSessao);
				redirect(base_url("login"));
				echo "Senha ou Login incorretos";				
			}	
		}
	}	
		
}
