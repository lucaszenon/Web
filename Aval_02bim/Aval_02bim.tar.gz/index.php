<!--Lucas e Wesley-->
<?php
	require_once 'init.php';
	// abre a conexão
	$PDO=db_connect();
	/* SQL para contar o total de registros */
	$sql_count = "SELECT COUNT(*) AS total FROM clientes ORDER BY nomeCliente ASC";
	$sql_count = "SELECT COUNT(*) AS total FROM fornecedores ORDER BY nomeFornecedor ASC";	
	// SQL para selecionar os registros
	$sql = " SELECT idCliente, nomeCliente, dataCadastro, email FROM clientes ORDER BY nomeCliente ASC";
	$sql = " SELECT idFornecedor, nomeFornecedor, dataFundacao, email FROM fornecedores ORDER BY nomeFornecedor ASC";
	// conta o total de registros
	$stmt_count=$PDO->prepare($sql_count);
	$stmt_count->execute();
	$total=$stmt_count->fetchColumn();
	// seleciona os registros
	$stmt=$PDO->prepare($sql);
	$stmt->execute();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
	<link type="text/css" href="js/jquery-ui.css" rel="stylesheet"/>
    <link type="text/css" href="style.css" rel="stylesheet"/>
    <script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.js"></script>
    <script type="text/javascript" src="js/script.js"></script>
	<script type ="text/javascript" src="js/datepicker-pt-BR.js"></script>
			
	<script>
function a(){
$("#data").datepicker({
showOn:  "button",
minDate: new Date(2000, 1 - 1, 1), 
maxDate: 0,        
buttonImage: "horse.jpg",
buttonImageOnly: true
});
 }
function b(){
$("#data").datepicker({
showOn:  "button",
minDate: new Date(1950, 1 - 1, 1), 
maxDate: 0,        
buttonImage: "horse.jpg",
buttonImageOnly: true
});
 }
 </script>

		<title>Cadastro de clientes</title>
	</head>
	<body>
		<div class="cabecalho">
			<div id="logo"><img src="images.jpg"></img></div>
			<div id="menu">
			<a href="index.php">HOME</a>
			<a href="clientes.php">CLIENTES</a>
			<a href="fornecedores.php">FORNECEDORES</a>
			<a href="sobre.php">SOBRE</a></div></div>
	
     
	<div class="container">
	
		<div>
			<h1>Mueno Enterprise</h1>
		<h3> <p>		Caros amigos, a hegemonia do ambiente político nos obriga à análise das direções preferenciais no sentido do progresso. O empenho em analisar o desafiador cenário globalizado faz parte de um processo de gerenciamento das formas de ação. Assim mesmo, o julgamento imparcial das eventualidades exige a precisão e a definição do sistema de formação de quadros que corresponde às necessidades. </p>

	        <p>		No entanto, não podemos esquecer que a necessidade de renovação processual causa impacto indireto na reavaliação do retorno esperado a longo prazo. A nível organizacional, a consolidação das estruturas prepara-nos para enfrentar situações atípicas decorrentes das posturas dos órgãos dirigentes com relação às suas atribuições. Pensando mais a longo prazo, o desenvolvimento contínuo de distintas formas de atuação assume importantes posições no estabelecimento dos métodos utilizados na avaliação de resultados. O que temos que ter sempre em mente é que a valorização de fatores subjetivos é uma das consequências do investimento em reciclagem técnica. </p>

         <p>		 Todas estas questões, devidamente ponderadas, levantam dúvidas sobre se o aumento do diálogo entre os diferentes setores produtivos pode nos levar a considerar a reestruturação das diretrizes de desenvolvimento para o futuro. O incentivo ao avanço tecnológico, assim como a crescente influência da mídia oferece uma interessante oportunidade para verificação dos índices pretendidos. Evidentemente, o entendimento das metas propostas não pode mais se dissociar do fluxo de informações.</p></h3>
		</div>
</div>
			
	 <div class="rodape">
        <h2>MUENO ENTERPRISE &copy; Copyright 2016 -all rights reserved</h2>
      </div>
	</body>
</html>
