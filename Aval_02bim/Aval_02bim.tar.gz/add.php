//add
<?php
	require_once 'init.php';
	include_once 'clientes.class.php';
	
	//pega os dados do formulário
	
	$name = isset($_POST['txtNome']) ? $_POST['txtNome'] : null;
	$email = isset($_POST['txtEmail']) ? $_POST['txtEmail'] : null;
	$dataCadastro = isset($_POST['txtData']) ? $_POST['txtData'] : null;
	
	//validação simples se campos estão vazios
	if(empty($name) || empty($dataCadastro) || empty($email))
	{
		echo "Campos devem ser preenchidos!!";
		exit;
	}

	//validação de email

	function validaEmail($email) {
	$conta = "^[a-zA-Z0-9\._-]+@";
	$domino = "[a-zA-Z0-9\._-]+.";
	$extensao = "([a-zA-Z]{2,4})$";
	$pattern = $conta.$domino.$extensao;
		if (ereg($pattern, $email))
			return true;
		else
			return false;
		}

	//instancia objeto cliente
	$cliente = new Cliente($name,$email,$dataCadastro);

			
	// insere no BD
	$PDO = db_connect();
	$sql = "INSERT INTO clientes(nomeCliente, email, dataCadastro) VALUES (:name, :email, :dataCadastro)";
	$stmt = $PDO->prepare($sql);
	$stmt->bindParam(':name', $cliente->getNome());
	$stmt->bindParam(':email', $cliente->getEmail());
	$stmt->bindParam(':dataCadastro', $cliente->getDataCadastro());
	if($stmt->execute())
	{
	echo $dataCadastro;
			
		header('Location: index.php');
	}
	else
	{
		echo "Erro ao cadastrar!!";
		print_r($stmt->errorInfo());
	}
?>
