<?php
	include_once 'cliente.class.php';
	include_once 'conexao.class.php';
//recebe os dados do formúlario
	$dadosOK = true;
		
		$aluno = new Cliente($_POST['txtNome'],$_POST['txtData'],$_POST['txtEmail']);
		
		$MySQL = new MySQL;
		
		try{
			$MySQL->inserirCliente($Cliente->getNome(),$cliente->getDataCadastro(),$cliente->getEmail());
			echo "<b>Dados gravados com sucesso</b> <br>";
		}catch (Exception $e){
			echo "Erro ao inserir: ". $e->getMessage() . "<br>";
		 }
	}
?>
